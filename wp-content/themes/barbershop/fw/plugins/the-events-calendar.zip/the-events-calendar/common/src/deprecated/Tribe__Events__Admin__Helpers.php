<?php
_deprecated_file( __FILE__, '4.0', 'Tribe__Admin__Helpers.php' );

class Tribe__Events__Admin__Helpers extends Tribe__Admin__Helpers {}
