<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Date_Utils' );


	class TribeDateUtils extends Tribe__Date_Utils {

	}
